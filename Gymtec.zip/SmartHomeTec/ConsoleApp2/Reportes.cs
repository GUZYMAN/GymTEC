﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Reportes
    {
        private string reportVentas;
        public Reportes()
        {
            this.reportVentas = "Top 10 platos mas vendidos: \n" + "1. Gallo Pinto 2. Sopa Azteca 3. Pollo frito 4. Casado 5. Torta de atun 6. Torta de carne" +
            "7. Carne en salsa 8. Lentejas 9. Garbanzos 10. Chicharrones" + "\n" +
            "Top 10 de los platos que más ganancias generan: \n" + "1. Gallo Pinto 2. Sopa Azteca 3. Pollo frito 4. Casado 5. Torta de atun 6. Torta de carne" +
            "7. Carne en salsa 8. Lentejas 9. Garbanzos 10. Chicharrones" + "\n" +
            "Top 10 de los platos con mejor feedback: \n" + "1. Gallo Pinto 2. Sopa Azteca 3. Pollo frito 4. Casado 5. Torta de atun 6. Torta de carne" +
            "7. Carne en salsa 8. Lentejas 9. Garbanzos 10. Chicharrones" + "\n" +
            "Top 10 de los clientes que más órdenes han generado: \n" + "1. Gallo Pinto 2. Sopa Azteca 3. Pollo frito 4. Casado 5. Torta de atun 6. Torta de carne" +
            "7. Carne en salsa 8. Lentejas 9. Garbanzos 10. Chicharrones" + "\n";
        }

        public string Report { get => reportVentas; }
    }
}
