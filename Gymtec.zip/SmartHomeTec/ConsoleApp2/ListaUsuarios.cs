﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{


    static class ListaUsuarios
    {
        static List<Usuario> _list;

        static ListaUsuarios()
        {
            // Allocate the list.
            _list = new List<Usuario>();
        }

        public static void Record(Usuario value)
        {
            // Record this value in the list.
            _list.Add(value);
        }

        public static void Display()
        {
            // Write out the results.
            foreach (var value in _list)
            {
                Console.WriteLine(value.Cedula);
            }
        }
    }
}


