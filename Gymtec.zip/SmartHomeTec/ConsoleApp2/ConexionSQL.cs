﻿using System;
using System.Web.Script.Serialization;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace ConsoleApp2
{
    class ConexionSQL
    {
        NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id = postgres; Password = guzymantec; Database = Smart_Home_DB");

        public void conectar()
        {
            conn.Open();
            Console.WriteLine("Conectado");

        }

        public void desconectar()
        {
            conn.Close();
            Console.WriteLine("Desconectado");
        }

        public string consultarU()
        {

            string query = "select * from \"usuarios\"";
            NpgsqlCommand connector = new NpgsqlCommand(query, conn);
            NpgsqlDataAdapter datos = new NpgsqlDataAdapter(connector);
            DataTable tabla = new DataTable();
            datos.Fill(tabla);

            string result = ConvertDataTabletoString(tabla);
            return result;

        }


        public string consultarU(string email)
        {

            string query = "select * from \"usuarios\" where \"email\" = '" + email + "'";
            NpgsqlCommand connector = new NpgsqlCommand(query, conn);
            NpgsqlDataAdapter datos = new NpgsqlDataAdapter(connector);
            DataTable tabla = new DataTable();
            datos.Fill(tabla);

            string result = ConvertDataTabletoString(tabla);
            return result;

        }

        



        public void insertarU(string nombre, string apellido1, string apellido2, 
            string password, string email, string direcciones, string region)
        {



            string query = "Insert into \"usuarios\" values (" + "'" + nombre + "'" + "," + "'" + apellido1 + "'" + ","
                                                               + "'" + apellido2 + "'" + "," + "'" + password + "'" + ","
                                                               + "'" + email + "'" + "," + "'" + direcciones + "'" + "," + "'" + region + "'" + ")";

            NpgsqlCommand ejecutor = new NpgsqlCommand(query, conn);
            ejecutor.ExecuteNonQuery();
            Console.WriteLine("Hecho");


        }




        public void eliminarU(string email)
        {
            string query = "Delete from \"usuarios\" " + "where \"email\" = '" + email + "'";

            NpgsqlCommand ejecutor = new NpgsqlCommand(query, conn);

            ejecutor.ExecuteNonQuery();

        }



        public void modificarU(string nombre, string apellido1, string apellido2, string password, string email, string direcciones, string region)
        {



            string query = "Update \"usuarios\" set \"nombre\" = '" + nombre + "'," +
                " \"apelllido1\" = '" + apellido1 + "', \"apelllido2\" = '" + apellido2 + "', \"password\" = '" + password + "'," +
                " \"direcciones\" = '" + direcciones + "', \"egion\" = '" + region + "'" +
                "" + " where \"email\" = '" + email + "'";

            NpgsqlCommand ejecutor = new NpgsqlCommand(query, conn);
            ejecutor.ExecuteNonQuery();
            Console.WriteLine("Hecho");
        }

        public string ConvertDataTabletoString(DataTable dt)
        {
            
                
                    
                    System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                    List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
                    Dictionary<string, object> row;
                    foreach (DataRow dr in dt.Rows)
                    {
                        row = new Dictionary<string, object>();
                        foreach (DataColumn col in dt.Columns)
                        {
                            row.Add(col.ColumnName, dr[col]);
                        }
                        rows.Add(row);
                    }
                    return serializer.Serialize(rows);
                
            
        }


        










    }
}
