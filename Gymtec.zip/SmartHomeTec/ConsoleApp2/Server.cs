﻿using Nancy;
using Nancy.Extensions;
using System;
using System.IO;
using System.Text;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace ConsoleApp2
{
    public class Server : NancyModule
    {
        static List<Usuario> users = new List<Usuario>();
        ConexionSQL sql = new ConexionSQL();

        public Server() : base("/")
        {



            Get["/usuarios"] = _ =>
            {
            


                sql.conectar();
                sql.consultarU();

                
                string response = sql.consultarU();
                var jsonBytes = Encoding.UTF8.GetBytes(response);
                return new Response
                {
                    ContentType = "application/json",
                    Contents = s => s.Write(jsonBytes, 0, jsonBytes.Length)

                };
            };


            Get["/reportes"] = _ =>
            {
                Console.WriteLine("get: /reportes");
                Reportes report = new Reportes();
                var jsonBytes = Encoding.UTF8.GetBytes(report.Report);
                return new Response
                {
                    ContentType = "application/json",
                    Contents = s => s.Write(jsonBytes, 0, jsonBytes.Length)
                };
            };






            Post["/regU"] = x =>
            {
                Console.WriteLine("post: /regU");
                string json = this.Request.Body.AsString();
                JObject data = JObject.Parse(json);
                Console.WriteLine("Request:\n" + data);

                string nombre = data["nombre"].ToString();
                string apellido1 = data["apellido1"].ToString();
                string apellido2 = data["apellido2"].ToString();
                string password = data["password"].ToString();
                string email = data["email"].ToString();
                string direcciones = data["direcciones"].ToString();
                string region = data["region"].ToString();

                sql.conectar();
                sql.insertarU(nombre, apellido1, apellido2, password, email, direcciones, region);

          
                string response = "Usuario creado";
                
                Console.WriteLine("Response:\n" + response);

                var jsonBytes = Encoding.UTF8.GetBytes(response);
                return new Response
                {
                ContentType = "application/json",
                Contents = s => s.Write(jsonBytes, 0, jsonBytes.Length)
                };
            };

            Post["/deleteU"] = x =>
            {

                string json = this.Request.Body.AsString();
                JObject data = JObject.Parse(json);
                Console.WriteLine("Request:\n" + data);

                string email = data["email"].ToString();

                sql.conectar();
                sql.eliminarU(email);



                string response = "Usuario eliminado";
                var jsonBytes = Encoding.UTF8.GetBytes(response);
                return new Response
                {
                    ContentType = "application/json",
                    Contents = s => s.Write(jsonBytes, 0, jsonBytes.Length)
                };
            };





}
    }
}
