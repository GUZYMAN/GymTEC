﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Usuario
    {
        private string fecha;
        private string correo;
        private string p_apellido;
        private string cedula;
        private string s_apellido;
        private string nombre;
        private string contrasena;
        private string telefono;

        public string Fecha { get => fecha; set => fecha = value; }
        public string Correo { get => correo; set => correo = value; }
        public string P_apellido { get => p_apellido; set => p_apellido = value; }
        public string Cedula { get => cedula; set => cedula = value; }
        public string S_apellido { get => s_apellido; set => s_apellido = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Contrasena { get => contrasena; set => contrasena = value; }
        public string Telefono { get => telefono; set => telefono = value; }
    }
}
